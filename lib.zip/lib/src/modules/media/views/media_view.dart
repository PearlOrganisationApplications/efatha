import 'package:flutter/material.dart';
import '../../live/views/live_view.dart';
 // We can reuse Home components or create a new list for podcasts

class MediaView extends StatelessWidget {
  const MediaView({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          TabBar(
            labelColor: Theme.of(context).primaryColor,
            unselectedLabelColor: Colors.grey,
            tabs: const [
              Tab(text: 'LIVE TV', icon: Icon(Icons.live_tv)),
              Tab(text: 'PODCASTS', icon: Icon(Icons.mic)),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                const LiveView(),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.mic_none_outlined, size: 80, color: Theme.of(context).primaryColor),
                      ),
                      const SizedBox(height: 32),
                      Text(
                        'Podcast Gallery Coming Soon',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
