import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../home/controllers/home_controller.dart';
import '../../shop/controllers/shop_controller.dart';

class DashboardView extends StatelessWidget {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    // We can access multiple controllers here to show summary data
    final homeController = Get.find<HomeController>();
    final shopController = Get.find<ShopController>();

    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: RefreshIndicator(
        onRefresh: () async {
          await homeController.fetchContent();
          await shopController.fetchProducts();
        },
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeading('Live Stream'),
              _buildLiveCard(),
              const SizedBox(height: 24),
              _buildHeading('Recent Updates'),
              _buildSummarySection(homeController),
              const SizedBox(height: 24),
              _buildHeading('Featured Products'),
              _buildProductSection(shopController),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeading(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildLiveCard() {
    return Card(
      color: Colors.red.shade900,
      child: const ListTile(
        leading: Icon(Icons.live_tv, color: Colors.white),
        title: Text('Watch Live Now', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        subtitle: Text('EfathaTV Transformation Hour', style: TextStyle(color: Colors.white70)),
        trailing: Icon(Icons.arrow_forward_ios, color: Colors.white, size: 16),
      ),
    );
  }

  Widget _buildSummarySection(HomeController controller) {
    return Obx(() {
      if (controller.isLoading.value) return const Center(child: CircularProgressIndicator());
      if (controller.posts.isEmpty) return const Text('No recent posts');
      
      return Column(
        children: controller.posts.take(3).map((post) => ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(post.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(post.date, style: const TextStyle(fontSize: 12)),
          trailing: const Icon(Icons.chevron_right),
        )).toList(),
      );
    });
  }

  Widget _buildProductSection(ShopController controller) {
    return Obx(() {
      if (controller.isLoading.value) return const Center(child: CircularProgressIndicator());
      if (controller.products.isEmpty) return const Text('No featured products');

      return SizedBox(
        height: 120,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: controller.products.take(5).length,
          itemBuilder: (context, index) {
            final product = controller.products[index];
            return Container(
              width: 100,
              margin: const EdgeInsets.only(right: 12),
              child: Column(
                children: [
                  if (product.imageUrl != null)
                    Expanded(child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(product.imageUrl!, fit: BoxFit.cover),
                    )),
                  Text(product.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10)),
                ],
              ),
            );
          },
        ),
      );
    });
  }
}
