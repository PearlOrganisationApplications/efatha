import 'package:get/get.dart';
import '../../../data/models/portfolio.dart';
import '../../../data/repositories/portfolio_repository.dart';

class PortfolioController extends GetxController {
  final PortfolioRepository _repository;

  PortfolioController(this._repository);

  final portfolios = <Portfolio>[].obs;
  final isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    fetchPortfolios();
  }

  Future<void> fetchPortfolios() async {
    isLoading.value = true;
    try {
      final fetchedPortfolios = await _repository.getPortfolios();
      portfolios.assignAll(fetchedPortfolios);
    } catch (e) {
      portfolios.clear(); // Fail gracefully
    } finally {
      isLoading.value = false;
    }
  }
}
