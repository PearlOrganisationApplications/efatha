import 'package:get/get.dart';
import '../../../data/repositories/portfolio_repository.dart';
import '../controllers/portfolio_controller.dart';

class PortfolioBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PortfolioController>(
      () => PortfolioController(Get.find<PortfolioRepository>()),
    );
  }
}
