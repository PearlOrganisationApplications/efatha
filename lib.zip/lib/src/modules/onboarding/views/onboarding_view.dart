import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/onboarding_controller.dart';

class OnboardingView extends GetView<OnboardingController> {
  const OnboardingView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        children: [
          _buildPage(
            title: 'Welcome to EfathaTV',
            description: 'Experience transformation through media.',
            icon: Icons.tv,
            color: Colors.blue.shade900,
          ),
          _buildPage(
            title: 'Real-Time Content',
            description: 'Stay updated with live broadcasts and news.',
            icon: Icons.live_tv,
            color: Colors.red.shade900,
          ),
          _buildPage(
            title: 'Secure Education',
            description: 'Access our store and educational resources.',
            icon: Icons.school,
            color: Colors.green.shade900,
            isLast: true,
          ),
        ],
      ),
    );
  }

  Widget _buildPage({
    required String title,
    required String description,
    required IconData icon,
    required Color color,
    bool isLast = false,
  }) {
    return Container(
      color: color,
      padding: const EdgeInsets.all(40),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 120, color: Colors.white),
          const SizedBox(height: 40),
          Text(
            title,
            style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Text(
            description,
            style: const TextStyle(color: Colors.white70, fontSize: 18),
            textAlign: TextAlign.center,
          ),
          if (isLast) ...[
            const SizedBox(height: 60),
            ElevatedButton(
              onPressed: controller.completeOnboarding,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: color,
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              ),
              child: const Text('GET STARTED', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ],
      ),
    );
  }
}
