import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/home_controller.dart';
import '../../../shared/widgets/post_card.dart';
import '../../../shared/widgets/shimmer_loading.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.isLoading.value && controller.posts.isEmpty) {
        return _buildLoadingSkeleton(context);
      }

      return RefreshIndicator(
        onRefresh: controller.fetchContent,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (controller.featuredPost.value != null) _buildHeroSlider(),
              if (controller.programs.isNotEmpty) ...[
                _buildSectionHeader('OUR PROGRAMS'),
                _buildProgramsGrid(),
                const SizedBox(height: 24),
              ],
              if (controller.posts.isNotEmpty) ...[
                _buildSectionHeader('RECENT NEWS'),
                _buildRecentPosts(),
                const SizedBox(height: 24),
              ],
              if (controller.podcasts.isNotEmpty) ...[
                _buildSectionHeader('PODCASTS'),
                _buildPodcastsList(),
                const SizedBox(height: 24),
              ],
            ],
          ),
        ),
      );
    });
  }

  Widget _buildHeroSlider() {
    final post = controller.featuredPost.value!;
    return Stack(
      children: [
        Container(
          height: 320,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.grey.shade900,
          ),
          child: post.featuredMediaUrl != null
              ? Image.network(
                  post.featuredMediaUrl!,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) return child;
                    return const ShimmerLoading(width: double.infinity, height: 320, borderRadius: 0);
                  },
                )
              : null,
        ),
        Container(
          height: 320,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: const [0.4, 1.0],
              colors: [Colors.transparent, Colors.black.withValues(alpha: 0.9)],
            ),
          ),
        ),
        Positioned(
          bottom: 30,
          left: 20,
          right: 20,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.redAccent,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text('FEATURED', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
              ),
              const SizedBox(height: 12),
              Text(
                post.title,
                style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold, height: 1.2),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Text(
        title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 1.2),
      ),
    );
  }

  Widget _buildProgramsGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: controller.programs.length,
      itemBuilder: (context, index) {
        final program = controller.programs[index];
        return ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (program.featuredMediaUrl != null)
                Image.network(program.featuredMediaUrl!, fit: BoxFit.cover),
              Container(color: Colors.black26),
              Center(
                child: Text(
                  program.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRecentPosts() {
    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: controller.posts.length,
      separatorBuilder: (_, ___) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final post = controller.posts[index];
        return PostCard(post: post);
      },
    );
  }

  Widget _buildPodcastsList() {
    return SizedBox(
      height: 180,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: controller.podcasts.length,
        itemBuilder: (context, index) {
          final podcast = controller.podcasts[index];
          return Container(
            width: 140,
            margin: const EdgeInsets.only(right: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    height: 110,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.blue.shade900, Colors.purple.shade700],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: const Center(child: Icon(Icons.mic, color: Colors.white, size: 40)),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  podcast.title, 
                  maxLines: 2, 
                  overflow: TextOverflow.ellipsis, 
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, height: 1.2),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildLoadingSkeleton(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const ShimmerLoading(width: double.infinity, height: 320, borderRadius: 0),
          const SizedBox(height: 24),
          _buildSectionHeader('OUR PROGRAMS'),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const Expanded(child: ShimmerLoading(width: double.infinity, height: 120, borderRadius: 12)),
                const SizedBox(width: 12),
                const Expanded(child: ShimmerLoading(width: double.infinity, height: 120, borderRadius: 12)),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('RECENT NEWS'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: const [
                PostCardSkeleton(),
                PostCardSkeleton(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
