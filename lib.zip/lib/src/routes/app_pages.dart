import 'package:get/get.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/home_view.dart';
import '../modules/shop/bindings/shop_binding.dart';
import '../modules/shop/views/shop_view.dart';
import '../modules/portfolio/bindings/portfolio_binding.dart';
import '../modules/portfolio/views/portfolio_view.dart';
import '../modules/live/views/live_view.dart';
import '../modules/about/views/about_view.dart';
import '../modules/index/bindings/index_binding.dart';
import '../modules/index/views/index_view.dart';
import '../modules/onboarding/bindings/onboarding_binding.dart';
import '../modules/onboarding/views/onboarding_view.dart';
import '../modules/media/views/media_view.dart';
import '../modules/donate/views/donate_view.dart';
import '../../splash_screen.dart';
import 'app_routes.dart';

class AppPages {
  static const initial = AppRoutes.splash;

  static final routes = [
    GetPage(
      name: AppRoutes.splash,
      page: () => const SplashScreen(),
    ),
    GetPage(
      name: AppRoutes.onboarding,
      page: () => const OnboardingView(),
      binding: OnboardingBinding(),
    ),
    GetPage(
      name: AppRoutes.index,
      page: () => const IndexView(),
      bindings: [
        IndexBinding(),
        HomeBinding(),
        ShopBinding(),
      ],
    ),
    GetPage(
      name: AppRoutes.home,
      page: () => const HomeView(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: AppRoutes.shop,
      page: () => const ShopView(),
      binding: ShopBinding(),
    ),
    GetPage(
      name: AppRoutes.media,
      page: () => const MediaView(),
    ),
    GetPage(
      name: AppRoutes.donate,
      page: () => const DonateView(),
    ),
    GetPage(
      name: AppRoutes.portfolio,
      page: () => const PortfolioView(),
      binding: PortfolioBinding(),
    ),
    GetPage(
      name: AppRoutes.live,
      page: () => const LiveView(),
    ),
    GetPage(
      name: AppRoutes.about,
      page: () => const AboutView(),
    ),
  ];
}
