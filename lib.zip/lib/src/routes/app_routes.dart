abstract class AppRoutes {
  static const String splash = '/splash';
  static const String onboarding = '/onboarding';
  static const String index = '/'; // Setting Index (Dashboard) as the home after splash/onboarding
  static const String home = '/home';
  static const String shop = '/shop';
  static const String media = '/media';
  static const String donate = '/donate';
  static const String portfolio = '/portfolio';
  static const String podcasts = '/podcasts';
  static const String live = '/live';
  static const String about = '/about';
}
