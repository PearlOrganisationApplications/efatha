import '../models/wp_post.dart';
import '../models/wp_podcast.dart';
import '../providers/base_provider.dart';
import '../../core/utils/api_constants.dart';
import 'package:get/get.dart';

class ContentRepository extends GetxService {
  final BaseProvider _provider;

  ContentRepository(this._provider);

  // Real posts originate from efathatv.com. Imported xtemos demo posts have GUIDs from dummy.xtemos.com.
  static bool _isRealPost(Map<String, dynamic> json) {
    final guid = (json['guid']?['rendered'] as String? ?? '').toLowerCase();
    // Keep posts from efathatv.com, reject anything from the dummy xtemos import
    return guid.contains('efathatv.com') && !guid.contains('dummy');
  }

  Future<List<WpPost>> getPosts({int page = 1, int perPage = 20}) async {
    try {
      final response = await _provider.get(
        ApiConstants.posts,
        queryParameters: {'page': page, 'per_page': perPage, '_embed': ''},
      );

      if (response.statusCode == 200 && response.data is List) {
        final List<dynamic> data = response.data;
        return data
            .where((json) => _isRealPost(json as Map<String, dynamic>))
            .map((json) => WpPost.fromJson(json as Map<String, dynamic>))
            .toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  Future<List<WpPodcast>> getPodcasts({int page = 1, int perPage = 20}) async {
    try {
      final response = await _provider.get(
        ApiConstants.podcasts,
        queryParameters: {'page': page, 'per_page': perPage},
      );

      if (response.statusCode == 200 && response.data is List) {
        final List<dynamic> data = response.data;
        // Only include posts that actually have an audio file (real podcast episodes)
        return data
            .where((json) {
              final meta = (json as Map<String, dynamic>)['meta'] ?? {};
              final audioFile = (meta['audio_file'] as String? ?? '').trim();
              return audioFile.isNotEmpty;
            })
            .map((json) => WpPodcast.fromJson(json as Map<String, dynamic>))
            .toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }
}
